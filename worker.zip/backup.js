let container = document.getElementById("container");
let textOut = document.getElementById("text");
let iteration = document.getElementById("iteration");
let character = document.getElementById("character");
let action = document.getElementById("action");


let slideText = ["My Name is Prabhu Appu",
    "I'm testing my code here",
    "I'm planning to create youtube video on this",
    "I'm planning to create youtube video using this video code",
    "I'm planning to help others using this video",
]
slideText = [`
<figure class="bg-gray-100 rounded-xl">
  <img class="w-32 h-32" src="/sarah-dayan.jpg" alt="" width="384" height="512">
  <div class="pt-6 space-y-4">
    <blockquote>
      <p class="text-lg">
        “Tailwind CSS is the only framework that I've seen scale
        on large teams. It’s easy to customize, adapts to any design,
        and the build size is tiny.”
      </p>
    </blockquote>
    <figcaption>
      <div>
        Sarah Dayan
      </div>
      <div>
        Staff Engineer, Algolia
      </div>
    </figcaption>
  </div>
</figure>
`,

    `
<figure class="bg-gray-100 rounded-xl p-8">
  <img class="w-32 h-32 rounded-full mx-auto" src="/sarah-dayan.jpg" alt="" width="384" height="512">
  <div class="pt-6 space-y-4">
    <blockquote>
      <p class="text-lg font-semibold">
        “Tailwind CSS is the only framework that I've seen scale
        on large teams. It’s easy to customize, adapts to any design,
        and the build size is tiny.”
      </p>
    </blockquote>
    <figcaption>
      <div>
        Sarah Dayan
      </div>
      <div>
        Staff Engineer, Algolia
      </div>
    </figcaption>
  </div>
</figure>
`,
    `<figure class="md:flex bg-gray-100 rounded-xl p-8 md:p-0">
  <img class="w-32 h-32 md:w-48 md:h-auto md:rounded-none rounded-full mx-auto" src="/sarah-dayan.jpg" alt="" width="384" height="512">
  <div class="pt-6 md:p-8 text-center md:text-left space-y-4">
    <blockquote>
      <p class="text-lg font-semibold">
        “Tailwind CSS is the only framework that I've seen scale
        on large teams. It’s easy to customize, adapts to any design,
        and the build size is tiny.”
      </p>
    </blockquote>
    <figcaption class="font-medium">
      <div class="text-cyan-600">
        Sarah Dayan
      </div>
      <div class="text-gray-500">
        Staff Engineer, Algolia
      </div>
    </figcaption>
  </div>
</figure>`
]
textOut.textContent = slideText[0];
let initialText = slideText[0];
let slideNo = 1;
let targetText = slideText[slideNo];

// const a = 'lebronnjabes';
// const b = 'lebronjames';
let difference = patienceDiff(initialText.split(""), targetText.split(""));
console.log(difference)
let start = difference.lines.length - 1;
let actualPosition = 0;
let text = slideText[0];
let delay = 20;
function addStr(str, index, stringToAdd) {
    return str.substring(0, index) + stringToAdd + str.substring(index, str.length);
}

function process() {

    difference.lines.forEach((item) => {
        if (item.bIndex === -1) {
            item['action'] = 'remove';
        } else if (item.aIndex === -1) {
            item['action'] = 'add';
        } else {
            item['action'] = 'retain';
        }
    })
}
process()
function animateRemove() {

    if (start >= 0) {
        let item = difference.lines[start]

        if (item.action === "remove") {
            text = text.slice(0, item.aIndex) + text.slice(item.aIndex + 1);
        }
        textOut.textContent = text
        iteration.textContent = start
        character.textContent = difference.lines[start].line
        action.textContent = item.action

        // initialText.split("")[item.aIndex]
        start--;
        item = difference.lines[start]
        if (item) {
            if (item.action === "remove") {
                setTimeout(animateRemove, delay);
            } else {
                animateRemove();
            }
        } else {
            if (start < 0) {
                start = 0;
            }
            setTimeout(animateAdd, delay);
        }
    }


    // if (start < difference.lines.length && difference.lines[start].aIndex === -1 && difference.lines[start].bIndex !== -1) {
    //     setTimeout(animate, delay);
    // } else if (start < difference.lines.length) {
    //     if (difference.lines[start].bIndex === -1) {
    //         setTimeout(animate, delay);
    //     }
    //     else {
    //         animate()
    //     }
    // }
}
function animateAdd() {

    if (start <= difference.lines.length - 1) {
        let item = difference.lines[start]

        if (item.action === "add") {
            // text +=  item.line
            text = addStr(text, item.bIndex, item.line)
        }
        textOut.textContent = text
        iteration.textContent = start
        character.textContent = difference.lines[start].line
        action.textContent = item.action

        // initialText.split("")[item.aIndex]

        start++;
        item = difference.lines[start]
        if (item) {
            if (item.action === "add") {
                setTimeout(animateAdd, delay);
            } else {
                animateAdd();
            }
        } else {
            // if (start < 0) {
            //     start = 0;
            // }
            // setTimeout(animateAdd, delay);
        }
    }

    // if (start < difference.lines.length && difference.lines[start].aIndex === -1 && difference.lines[start].bIndex !== -1) {
    //     setTimeout(animate, delay);
    // } else if (start < difference.lines.length) {
    //     if (difference.lines[start].bIndex === -1) {
    //         setTimeout(animate, delay);
    //     }
    //     else {
    //         animate()
    //     }
    // }
}


function animate1() {
    // console.log("changing character, ", difference.lines[start].line, actualPosition)
    if (difference.lines[start].bIndex !== -1 && difference.lines[start].aIndex === -1 && start < difference.lines.length) {
        // text += difference.lines[start].line
        container.textContent = addStr(container.textContent, start, difference.lines[start].line)
        actualPosition = container.textContent.length - 1;
        console.log("adding character at ", start, "actualPosition", actualPosition)
    } else {
        if (difference.lines[start].bIndex === -1) {
            container.textContent = container.textContent.slice(0, actualPosition) + container.textContent.slice(actualPosition + 1);
            console.log("removing character at ", actualPosition, 'start', start)
        } else {
            actualPosition++
            console.log("increasing pointer ", actualPosition, 'start', start)
        }
    }
    start++;
    // console.log(difference.lines[start].line, start < difference.lines.length, difference.lines[start].bIndex === -1)


    if (start < difference.lines.length && difference.lines[start].aIndex === -1 && difference.lines[start].bIndex !== -1) {
        setTimeout(animate, delay);
    } else if (start < difference.lines.length) {
        if (difference.lines[start].bIndex === -1) {
            setTimeout(animate, delay);
        }
        else {
            animate()
        }
    }
}

animateRemove()

document.getElementById("stepRemove").addEventListener('click', () => {
    animateRemove()
})
document.getElementById("stepAdd").addEventListener('click', () => {
    if (start < 0) {
        start = 0;
    }
    animateAdd()
})

// document.getElementById("next").addEventListener('click', () => {
//     initialText = container.innerText;

//     targetText = "This is my code test";

//     // const a = 'lebronnjabes';
//     // const b = 'lebronjames';
//     difference = patienceDiff(initialText.split(""), targetText.split(""));
//     console.log(difference)
//     start = 0;
//     actualPosition = 0;
//     text = container.textContent;
//     delay = 3000
//     animate();
// })
let playNext = () => {
    initialText = text;

    if (slideNo < slideText.length) {
        targetText = slideText[slideNo];;

        // const a = 'lebronnjabes';
        // const b = 'lebronjames';
        difference = patienceDiff(initialText.split(""), targetText.split(""));
        console.log(difference)
        start = difference.lines.length - 1;
        actualPosition = 0;
        text = text;
        delay = 80
        process()
        animateRemove()
    }
    // animate();
}
document.getElementById("previous").addEventListener('click', () => {
    slideNo--;
    playNext()
})
document.getElementById("next").addEventListener('click', () => {
    slideNo++;
    playNext()
})