let data = [
    {
        selector: "figure",
        className: "md:flex bg-gray-100 rounded-xl p-8 md:p-0",
        text: `<figure class="">
    <img class="" src="/sarah-dayan.jpg"
        alt="" width="384" height="512">
    <div class="">
        <blockquote>
            <p class="">
                “Tailwind CSS is the only framework that I've seen scale
                on large teams. It’s easy to customize, adapts to any design,
                and the build size is tiny.”
            </p>
        </blockquote>
        <figcaption class="">
            <div class="">
                Sarah Dayan
            </div>
            <div class="">
                Staff Engineer, Algolia
            </div>
        </figcaption>
    </div>
</figure>`
    },
    {
        selector: "figure",
        className: "md:flex bg-gray-100 rounded-xl p-8 md:p-0",
        text: `<figure class="md:flex bg-gray-100 rounded-xl p-8 md:p-0">
    <img class="" src="/sarah-dayan.jpg"
        alt="" width="384" height="512">
    <div class="">
        <blockquote>
            <p class="">
                “Tailwind CSS is the only framework that I've seen scale
                on large teams. It’s easy to customize, adapts to any design,
                and the build size is tiny.”
            </p>
        </blockquote>
        <figcaption class="">
            <div class="">
                Sarah Dayan
            </div>
            <div class="">
                Staff Engineer, Algolia
            </div>
        </figcaption>
    </div>
</figure>`
    },
    {
        selector: "figure img",
        className: "w-32 h-32 md:w-48 md:h-auto md:rounded-l-xl md:rounded-r-none rounded-full mx-auto",
        text: `<figure class="md:flex bg-gray-100 rounded-xl p-8 md:p-0">
    <img class="w-32 h-32 md:w-48 md:h-auto md:rounded-l-xl md:rounded-r-none rounded-full mx-auto" src="/sarah-dayan.jpg"
        alt="" width="384" height="512">
    <div class="">
        <blockquote>
            <p class="">
                “Tailwind CSS is the only framework that I've seen scale
                on large teams. It’s easy to customize, adapts to any design,
                and the build size is tiny.”
            </p>
        </blockquote>
        <figcaption class="">
            <div class="">
                Sarah Dayan
            </div>
            <div class="">
                Staff Engineer, Algolia
            </div>
        </figcaption>
    </div>
</figure>`
    },
    {
        selector: "figure>div",
        className: "pt-6 md:p-8 text-center md:text-left space-y-4",
        text: `<figure class="md:flex bg-gray-100 rounded-xl p-8 md:p-0">
    <img class="w-32 h-32 md:w-48 md:h-auto md:rounded-l-xl md:rounded-r-none rounded-full mx-auto" src="/sarah-dayan.jpg"
        alt="" width="384" height="512">
    <div class="pt-6 md:p-8 text-center md:text-left space-y-4">
        <blockquote>
            <p class="">
                “Tailwind CSS is the only framework that I've seen scale
                on large teams. It’s easy to customize, adapts to any design,
                and the build size is tiny.”
            </p>
        </blockquote>
        <figcaption class="">
            <div class="">
                Sarah Dayan
            </div>
            <div class="">
                Staff Engineer, Algolia
            </div>
        </figcaption>
    </div>

</figure>`
    },
    {
        selector: "figure>div p",
        className: "text-lg font-semibold",
        text: `<figure class="md:flex bg-gray-100 rounded-xl p-8 md:p-0">
    <img class="w-32 h-32 md:w-48 md:h-auto md:rounded-l-xl md:rounded-r-none rounded-full mx-auto" src="/sarah-dayan.jpg"
        alt="" width="384" height="512">
    <div class="pt-6 md:p-8 text-center md:text-left space-y-4">
        <blockquote>
            <p class="text-lg font-semibold">
                “Tailwind CSS is the only framework that I've seen scale
                on large teams. It’s easy to customize, adapts to any design,
                and the build size is tiny.”
            </p>
        </blockquote>
        <figcaption class="">
            <div class="">
                Sarah Dayan
            </div>
            <div class="">
                Staff Engineer, Algolia
            </div>
        </figcaption>
    </div>
</figure>`
    },
    {
        selector: "figcaption",
        className: "font-medium",
        text: `<figure class="md:flex bg-gray-100 rounded-xl p-8 md:p-0">
    <img class="w-32 h-32 md:w-48 md:h-auto md:rounded-l-xl md:rounded-r-none rounded-full mx-auto" src="/sarah-dayan.jpg"
        alt="" width="384" height="512">
    <div class="pt-6 md:p-8 text-center md:text-left space-y-4">
        <blockquote>
            <p class="text-lg font-semibold">
                “Tailwind CSS is the only framework that I've seen scale
                on large teams. It’s easy to customize, adapts to any design,
                and the build size is tiny.”
            </p>
        </blockquote>
        <figcaption class="font-medium">
            <div class="">
                Sarah Dayan
            </div>
            <div class="">
                Staff Engineer, Algolia
            </div>
        </figcaption>
    </div>
</figure>`
    },
    {
        selector: "figcaption>div:nth-child(1)",
        className: "text-yellow-500",
        text: `<figure class="md:flex bg-gray-100 rounded-xl p-8 md:p-0">
    <img class="w-32 h-32 md:w-48 md:h-auto md:rounded-l-xl md:rounded-r-none rounded-full mx-auto" src="/sarah-dayan.jpg"
        alt="" width="384" height="512">
    <div class="pt-6 md:p-8 text-center md:text-left space-y-4">
        <blockquote>
            <p class="text-lg font-semibold">
                “Tailwind CSS is the only framework that I've seen scale
                on large teams. It’s easy to customize, adapts to any design,
                and the build size is tiny.”
            </p>
        </blockquote>
        <figcaption class="font-medium">
            <div class="text-yellow-500">
                Sarah Dayan
            </div>
            <div class="">
                Staff Engineer, Algolia
            </div>
        </figcaption>
    </div>
</figure>`
    }, {
        selector: "figcaption>div:nth-child(2)",
        className: "text-gray-500",
        text: `<figure class="md:flex bg-gray-100 rounded-xl p-8 md:p-0">
    <img class="w-32 h-32 md:w-48 md:h-auto md:rounded-l-xl md:rounded-r-none rounded-full mx-auto" src="/sarah-dayan.jpg"
        alt="" width="384" height="512">
    <div class="pt-6 md:p-8 text-center md:text-left space-y-4">
        <blockquote>
            <p class="text-lg font-semibold">
                “Tailwind CSS is the only framework that I've seen scale
                on large teams. It’s easy to customize, adapts to any design,
                and the build size is tiny.”
            </p>
        </blockquote>
        <figcaption class="font-medium">
            <div class="text-yellow-500">
                Sarah Dayan
            </div>
            <div class="text-gray-500">
                Staff Engineer, Algolia
            </div>
        </figcaption>
    </div>
</figure>`
    }
]




data = [
    {
        selector: "figure",
        className: "",
        text: `
<figure class="">
    <img class="" src="/sarah-dayan.jpg"
        alt="" width="384" height="512">
    <div class="">
        <blockquote>
            <p class="">
                “Tailwind CSS is the only framework that I've seen scale
                on large teams. It’s easy to customize, adapts to any design,
                and the build size is tiny.”
            </p>
        </blockquote>
        <figcaption class="">
            <div class="">
                Sarah Dayan
            </div>
            <div class="">
                Staff Engineer, Algolia
            </div>
        </figcaption>
    </div>
</figure>`
    },
    {
        selector: "figure",
        className: "bg-gray-100 rounded-xl",
        text: `
<figure class="bg-gray-100 rounded-xl">
    <img class="" src="/sarah-dayan.jpg"
        alt="" width="384" height="512">
    <div class="">
        <blockquote>
            <p class="">
                “Tailwind CSS is the only framework that I've seen scale
                on large teams. It’s easy to customize, adapts to any design,
                and the build size is tiny.”
            </p>
        </blockquote>
        <figcaption class="">
            <div class="">
                Sarah Dayan
            </div>
            <div class="">
                Staff Engineer, Algolia
            </div>
        </figcaption>
    </div>
</figure>`
    },
    {
        selector: "figure",
        className: " p-8",
        text: `
<figure class="bg-gray-100 rounded-xl p-8">
    <img class="" src="/sarah-dayan.jpg"
        alt="" width="384" height="512">
    <div class="">
        <blockquote>
            <p class="">
                “Tailwind CSS is the only framework that I've seen scale
                on large teams. It’s easy to customize, adapts to any design,
                and the build size is tiny.”
            </p>
        </blockquote>
        <figcaption class="">
            <div class="">
                Sarah Dayan
            </div>
            <div class="">
                Staff Engineer, Algolia
            </div>
        </figcaption>
    </div>
</figure>`
    },
    {
        selector: "figure>img",
        className: "w-32 h-32",
        text: `
<figure class="bg-gray-100 rounded-xl p-8">
    <img class="w-32 h-32" src="/sarah-dayan.jpg"
        alt="" width="384" height="512">
    <div class="">
        <blockquote>
            <p class="">
                “Tailwind CSS is the only framework that I've seen scale
                on large teams. It’s easy to customize, adapts to any design,
                and the build size is tiny.”
            </p>
        </blockquote>
        <figcaption class="">
            <div class="">
                Sarah Dayan
            </div>
            <div class="">
                Staff Engineer, Algolia
            </div>
        </figcaption>
    </div>
</figure>`
    },
    {
        selector: "figure>img",
        className: "rounded-full",
        text: `
<figure class="bg-gray-100 rounded-xl p-8">
    <img class="w-32 h-32 rounded-full" src="/sarah-dayan.jpg"
        alt="" width="384" height="512">
    <div class="">
        <blockquote>
            <p class="">
                “Tailwind CSS is the only framework that I've seen scale
                on large teams. It’s easy to customize, adapts to any design,
                and the build size is tiny.”
            </p>
        </blockquote>
        <figcaption class="">
            <div class="">
                Sarah Dayan
            </div>
            <div class="">
                Staff Engineer, Algolia
            </div>
        </figcaption>
    </div>
</figure>`
    },
    {
        selector: "figure>img",
        className: "mx-auto",
        text: `
<figure class="bg-gray-100 rounded-xl p-8">
    <img class="w-32 h-32 rounded-full mx-auto" src="/sarah-dayan.jpg"
        alt="" width="384" height="512">
    <div class="">
        <blockquote>
            <p class="">
                “Tailwind CSS is the only framework that I've seen scale
                on large teams. It’s easy to customize, adapts to any design,
                and the build size is tiny.”
            </p>
        </blockquote>
        <figcaption class="">
            <div class="">
                Sarah Dayan
            </div>
            <div class="">
                Staff Engineer, Algolia
            </div>
        </figcaption>
    </div>
</figure>`
    },
    {
        selector: "figure p",
        className: "text-lg font-semibold",
        text: `
<figure class="bg-gray-100 rounded-xl p-8">
    <img class="w-32 h-32 rounded-full mx-auto" src="/sarah-dayan.jpg"
        alt="" width="384" height="512">
    <div class="">
        <blockquote>
            <p class="text-lg font-semibold">
                “Tailwind CSS is the only framework that I've seen scale
                on large teams. It’s easy to customize, adapts to any design,
                and the build size is tiny.”
            </p>
        </blockquote>
        <figcaption class="">
            <div class="">
                Sarah Dayan
            </div>
            <div class="">
                Staff Engineer, Algolia
            </div>
        </figcaption>
    </div>
</figure>`
    },
    {
        selector: "figcaption",
        className: "font-medium",
        text: `
<figure class="bg-gray-100 rounded-xl p-8">
    <img class="w-32 h-32 rounded-full mx-auto" src="/sarah-dayan.jpg"
        alt="" width="384" height="512">
    <div class="">
        <blockquote>
            <p class="text-lg font-semibold">
                “Tailwind CSS is the only framework that I've seen scale
                on large teams. It’s easy to customize, adapts to any design,
                and the build size is tiny.”
            </p>
        </blockquote>
        <figcaption class="font-medium">
            <div class="">
                Sarah Dayan
            </div>
            <div class="">
                Staff Engineer, Algolia
            </div>
        </figcaption>
    </div>
</figure>`
    },
    {
        selector: "figcaption>div:nth-child(1)",
        className: "text-cyan-600",
        text: `
<figure class="bg-gray-100 rounded-xl p-8">
    <img class="w-32 h-32 rounded-full mx-auto" src="/sarah-dayan.jpg"
        alt="" width="384" height="512">
    <div class="">
        <blockquote>
            <p class="text-lg font-semibold">
                “Tailwind CSS is the only framework that I've seen scale
                on large teams. It’s easy to customize, adapts to any design,
                and the build size is tiny.”
            </p>
        </blockquote>
        <figcaption class="font-medium">
            <div class="text-cyan-600">
                Sarah Dayan
            </div>
            <div class="">
                Staff Engineer, Algolia
            </div>
        </figcaption>
    </div>
</figure>`
    },
    {
        selector: "figcaption>div:nth-child(2)",
        className: "text-gray-500",
        text: `
<figure class="bg-gray-100 rounded-xl p-8">
    <img class="w-32 h-32 rounded-full mx-auto" src="/sarah-dayan.jpg"
        alt="" width="384" height="512">
    <div class="">
        <blockquote>
            <p class="text-lg font-semibold">
                “Tailwind CSS is the only framework that I've seen scale
                on large teams. It’s easy to customize, adapts to any design,
                and the build size is tiny.”
            </p>
        </blockquote>
        <figcaption class="font-medium">
            <div class="text-cyan-600">
                Sarah Dayan
            </div>
            <div class="text-gray-500">
                Staff Engineer, Algolia
            </div>
        </figcaption>
    </div>
</figure>`
    },
    {
        selector: "figure>div",
        className: "pt-6 text-center space-y-4",
        text: `
<figure class="bg-gray-100 rounded-xl p-8">
    <img class="w-32 h-32 rounded-full mx-auto" src="/sarah-dayan.jpg"
        alt="" width="384" height="512">
    <div class="pt-6 text-center space-y-4">
        <blockquote>
            <p class="text-lg font-semibold">
                “Tailwind CSS is the only framework that I've seen scale
                on large teams. It’s easy to customize, adapts to any design,
                and the build size is tiny.”
            </p>
        </blockquote>
        <figcaption class="font-medium">
            <div class="text-cyan-600">
                Sarah Dayan
            </div>
            <div class="text-gray-500">
                Staff Engineer, Algolia
            </div>
        </figcaption>
    </div>
</figure>`
    },
    {
        selector: "figure",
        className: "md:flex",
        text: `
<figure class="md:flex bg-gray-100 rounded-xl p-8">
    <img class="w-32 h-32 rounded-full mx-auto" src="/sarah-dayan.jpg"
        alt="" width="384" height="512">
    <div class="pt-6 text-center space-y-4">
        <blockquote>
            <p class="text-lg font-semibold">
                “Tailwind CSS is the only framework that I've seen scale
                on large teams. It’s easy to customize, adapts to any design,
                and the build size is tiny.”
            </p>
        </blockquote>
        <figcaption class="font-medium">
            <div class="text-cyan-600">
                Sarah Dayan
            </div>
            <div class="text-gray-500">
                Staff Engineer, Algolia
            </div>
        </figcaption>
    </div>
</figure>`
    },
    {
        selector: "figure",
        className: "md:p-0",
        text: `
<figure class="md:flex bg-gray-100 rounded-xl p-8 md:p-0">
    <img class="w-32 h-32 rounded-full mx-auto" src="/sarah-dayan.jpg"
        alt="" width="384" height="512">
    <div class="pt-6 text-center space-y-4">
        <blockquote>
            <p class="text-lg font-semibold">
                “Tailwind CSS is the only framework that I've seen scale
                on large teams. It’s easy to customize, adapts to any design,
                and the build size is tiny.”
            </p>
        </blockquote>
        <figcaption class="font-medium">
            <div class="text-cyan-600">
                Sarah Dayan
            </div>
            <div class="text-gray-500">
                Staff Engineer, Algolia
            </div>
        </figcaption>
    </div>
</figure>`
    },
    {
        selector: "figure>div",
        className: "md:p-8",
        text: `
<figure class="md:flex bg-gray-100 rounded-xl p-8 md:p-0">
    <img class="w-32 h-32 rounded-full mx-auto" src="/sarah-dayan.jpg"
        alt="" width="384" height="512">
    <div class="pt-6 md:p-8 text-center space-y-4">
        <blockquote>
            <p class="text-lg font-semibold">
                “Tailwind CSS is the only framework that I've seen scale
                on large teams. It’s easy to customize, adapts to any design,
                and the build size is tiny.”
            </p>
        </blockquote>
        <figcaption class="font-medium">
            <div class="text-cyan-600">
                Sarah Dayan
            </div>
            <div class="text-gray-500">
                Staff Engineer, Algolia
            </div>
        </figcaption>
    </div>
</figure>`
    },
    {
        selector: "figure>div",
        className: "md:text-left",
        text: `
<figure class="md:flex bg-gray-100 rounded-xl p-8 md:p-0">
    <img class="w-32 h-32 rounded-full mx-auto" src="/sarah-dayan.jpg"
        alt="" width="384" height="512">
    <div class="pt-6 md:p-8 text-center md:text-left space-y-4">
        <blockquote>
            <p class="text-lg font-semibold">
                “Tailwind CSS is the only framework that I've seen scale
                on large teams. It’s easy to customize, adapts to any design,
                and the build size is tiny.”
            </p>
        </blockquote>
        <figcaption class="font-medium">
            <div class="text-cyan-600">
                Sarah Dayan
            </div>
            <div class="text-gray-500">
                Staff Engineer, Algolia
            </div>
        </figcaption>
    </div>
</figure>`
    },
    {
        selector: "figure>img",
        className: "md:w-48",
        text: `
<figure class="md:flex bg-gray-100 rounded-xl p-8 md:p-0">
    <img class="w-32 h-32 md:w-48 rounded-full mx-auto" src="/sarah-dayan.jpg"
        alt="" width="384" height="512">
    <div class="pt-6 md:p-8 text-center md:text-left space-y-4">
        <blockquote>
            <p class="text-lg font-semibold">
                “Tailwind CSS is the only framework that I've seen scale
                on large teams. It’s easy to customize, adapts to any design,
                and the build size is tiny.”
            </p>
        </blockquote>
        <figcaption class="font-medium">
            <div class="text-cyan-600">
                Sarah Dayan
            </div>
            <div class="text-gray-500">
                Staff Engineer, Algolia
            </div>
        </figcaption>
    </div>
</figure>`
    },
    {
        selector: "figure>img",
        className: "md:h-auto",
        text: `
<figure class="md:flex bg-gray-100 rounded-xl p-8 md:p-0">
    <img class="w-32 h-32 md:w-48 md:h-auto rounded-full mx-auto" src="/sarah-dayan.jpg"
        alt="" width="384" height="512">
    <div class="pt-6 md:p-8 text-center md:text-left space-y-4">
        <blockquote>
            <p class="text-lg font-semibold">
                “Tailwind CSS is the only framework that I've seen scale
                on large teams. It’s easy to customize, adapts to any design,
                and the build size is tiny.”
            </p>
        </blockquote>
        <figcaption class="font-medium">
            <div class="text-cyan-600">
                Sarah Dayan
            </div>
            <div class="text-gray-500">
                Staff Engineer, Algolia
            </div>
        </figcaption>
    </div>
</figure>`
    },
    {
        selector: "figure>img",
        className: "md:rounded-none",
        text: `
<figure class="md:flex bg-gray-100 rounded-xl p-8 md:p-0">
    <img class="w-32 h-32 md:w-48 md:h-auto md:rounded-none rounded-full mx-auto" src="/sarah-dayan.jpg"
        alt="" width="384" height="512">
    <div class="pt-6 md:p-8 text-center md:text-left space-y-4">
        <blockquote>
            <p class="text-lg font-semibold">
                “Tailwind CSS is the only framework that I've seen scale
                on large teams. It’s easy to customize, adapts to any design,
                and the build size is tiny.”
            </p>
        </blockquote>
        <figcaption class="font-medium">
            <div class="text-cyan-600">
                Sarah Dayan
            </div>
            <div class="text-gray-500">
                Staff Engineer, Algolia
            </div>
        </figcaption>
    </div>
</figure>`
    },
]