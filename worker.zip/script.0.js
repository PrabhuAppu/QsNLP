// let container = document.getElementById("container");
let textOut = document.getElementById("text");
// let iteration = document.getElementById("iteration");
// let character = document.getElementById("character");
// let action = document.getElementById("action");
const code = document.querySelector('#text');
const worker = new Worker('worker.js');

let slideText = ["My Name is Prabhu Appu",
  "I'm testing my code here",
  "I'm planning to create youtube video on this",
  "I'm planning to create youtube video using this video code",
  "I'm planning to help others using this video",
]
slideText = data
textOut.textContent = slideText[0].text;
let initialText = slideText[0].text;
let slideNo = 0;
let targetText = slideText[slideNo].text;

// const a = 'lebronnjabes';
// const b = 'lebronjames';
let difference = patienceDiff(initialText.split(""), targetText.split(""));
console.log(difference)
let start = difference.lines.length - 1;
let actualPosition = 0;
let text = slideText[0].text;
let delay = 80;
function addStr(str, index, stringToAdd) {
  return str.substring(0, index) + stringToAdd + str.substring(index, str.length);
}

function process() {

  difference.lines.forEach((item) => {
    if (item.bIndex === -1) {
      item['action'] = 'remove';
    } else if (item.aIndex === -1) {
      item['action'] = 'add';
    } else {
      item['action'] = 'retain';
    }
  })

}
process()

document.querySelectorAll('pre code').forEach((block) => {
  hljs.highlightBlock(block);
});

function animateRemove() {

  if (start >= 0) {
    let item = difference.lines[start]

    if (item.action === "remove") {
      text = text.slice(0, item.aIndex) + text.slice(item.aIndex + 1);
      textOut.textContent = text
    }
    // iteration.textContent = start
    // character.textContent = difference.lines[start].line
    // action.textContent = item.action


    // initialText.split("")[item.aIndex]
    start--;
    // worker.onmessage = (event) => {
    //   code.innerHTML = event.data;

    // }
    // worker.postMessage(code.textContent);

    item = difference.lines[start]
    if (item) {
      if (item.action === "remove") {
        setTimeout(animateRemove, delay);
      } else {
        animateRemove();
      }
    } else {
      if (start < 0) {
        start = 0;
      }
      setTimeout(animateAdd, delay);
    }

    // document.querySelectorAll('pre code').forEach((block) => {
    //   hljs.highlightBlock(block);
    // });


  }

}
function animateAdd() {

  if (start <= difference.lines.length - 1) {
    let item = difference.lines[start]

    if (item.action === "add") {
      // text +=  item.line
      text = addStr(text, item.bIndex, item.line)
    }
    textOut.textContent = text
    // iteration.textContent = start
    // character.textContent = difference.lines[start].line
    // action.textContent = item.action

    // initialText.split("")[item.aIndex]

    start++;


    // worker.onmessage = (event) => {
    //   code.innerHTML = event.data;


    // }
    // worker.postMessage(code.textContent);


    item = difference.lines[start]
    if (item) {
      if (item.action === "add") {
        setTimeout(animateAdd, delay);
      } else {
        animateAdd();
      }
    } else {
      // document.querySelector(slideText[slideNo].selector).className = slideText[slideNo].className
      if (slideNo < slideText.length) {
        slideNo++;
        playNext();
        // slideText[slideNo].className.split(" ").forEach((classN, i) => {
        //   setTimeout(() => {
        //     $(slideText[slideNo].selector).addClass(classN);
        //     setTimeout(() => {

        //       slideNo++;
        //       playNext();
        //     }, 1500);
        //   }, 500 * i)
        // })
      }

      // if (start < 0) {
      //     start = 0;
      // }
      // setTimeout(animateAdd, delay);
    }

    // document.querySelectorAll('pre code').forEach((block) => {
    //   hljs.highlightBlock(block);
    // });

  } else {

  }
}





// document.getElementById("stepRemove").addEventListener('click', () => {
//   animateRemove()
// })
// document.getElementById("stepAdd").addEventListener('click', () => {
//   if (start < 0) {
//     start = 0;
//   }
//   animateAdd()
// })

let playNext = () => {
  initialText = text;

  if (slideNo < slideText.length) {
    targetText = slideText[slideNo].text;;

    // const a = 'lebronnjabes';
    // const b = 'lebronjames';
    difference = patienceDiff(initialText.split(""), targetText.split(""));
    console.log(difference)
    start = difference.lines.length - 1;
    actualPosition = 0;
    text = text;
    // delay = 80
    process()
    animateRemove()


  }
  // animate();
}
document.getElementById("previous").addEventListener('click', () => {
  slideNo--;
  playNext();

})
document.getElementById("next").addEventListener('click', () => {
  slideNo++;
  playNext();
  // debugger;
  // document.querySelector(slideText[slideNo].selector).className = "md:flex bg-gray-100 rounded-xl p-8 md:p-0";
  if (slideNo < slideText.length) {
    slideText[slideNo].className.split(" ").forEach((classN, i) => {
      setTimeout(() => {
        $(slideText[slideNo].selector).addClass(classN, 300);
      }, 500 * i)
    })
  }

  // $(slideText[slideNo].selector).stop().animate(  getClassContent("bg-gray-100"), {duration:500});

})

let l = null;
let loop = () => {
  slideNo++;
  playNext();
  // debugger;
  // document.querySelector(slideText[slideNo].selector).className = slideText[slideNo].className;
  // $(slideText[slideNo].selector).addClass(slideText[slideNo].className);
  // if (slideNo < slideText.length) {
  //   slideText[slideNo].className.split(" ").forEach((classN, i) => {
  //     setTimeout(() => {
  //       $(slideText[slideNo].selector).addClass(classN, 300);
  //     }, 500 * i)
  //   })
  // }



  // $(slideText[slideNo].selector).stop().animate(  getClassContent("bg-gray-100"), {duration:500});

}
loop();

