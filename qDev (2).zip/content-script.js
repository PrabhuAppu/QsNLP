//alert("my name is prabhu");
console.log("test Jquery", $);


setTimeout(function () {


	// var script = document.createElement('script');
	// script.textContent = "console.log('code', document.querySelector('.CodeMirror').CodeMirror)";
	// (document.head || document.documentElement).appendChild(script);
	// script.parentNode.removeChild(script);

	var s = document.createElement('script');
	s.src = chrome.runtime.getURL('jquery-3.6.0.min.js');
	s.onload = function () {
		// this.remove();
		var s = document.createElement('script');
		s.src = chrome.runtime.getURL('findAndReplace.js');
		s.onload = function () {
			// this.remove();
		};
		(document.head || document.documentElement).appendChild(s);
	};
	(document.head || document.documentElement).appendChild(s);

	// var s = document.createElement('script');
	// s.src = chrome.runtime.getURL('dialog.js');
	// s.onload = function () {
	// 	this.remove();
	// };
	// (document.head || document.documentElement).appendChild(s);




	
}, 3000);
//