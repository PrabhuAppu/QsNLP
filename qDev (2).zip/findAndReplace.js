console.log('code', document.querySelector('.CodeMirror').CodeMirror)


let projectName = window.location.hash.match(/\{(.*)\}/).pop();
let local_previousTab = projectName + "_previousTab";
let local_activeTab = projectName + "_activeTab";
let local_activeTabNumber = projectName + "_activeTabNumber";
let local_disableScroll = projectName + '_disableScroll';
let local_scrollMemory = projectName + "_scrollMemory";
let local_bookmark = projectName + "_bookmark";
let local_currentLineNumber = projectName + "_currentLineNumber";

var editor = document.querySelector('.CodeMirror').CodeMirror
var cursor = editor.getSearchCursor(/app1/);
while (cursor.findNext()) {
    console.log("Asass");
    editor.markText(
        cursor.from(),
        cursor.to(),
        { className: 'highlight' }
    );
}
var cursor = null;
let cmEditor = null;
// $('<button id="chMode"><span class="lui-icon  lui-icon--play" aria-hidden="true"></span></button>').insertAfter(".tab-view")
// $('<button id="start">search</button>').insertAfter(".tab-view")
// $('<button id="next">Next</button>').insertAfter(".tab-view")
// $('<input type="text" id="search" name="search" placeholder="search.."/>').insertAfter(".tab-view");

$('.qui-editbarflat.qw-center').append('<button title="Search" class="" id="showsearch"><span class="lui-icon  lui-icon--search" aria-hidden="true"></span></button>');
$('.qui-editbarflat.qw-center').append('<input title="Search" class="" type="text" id="searchText" name="search" placeholder="Search"/>');
$('.qui-editbarflat.qw-center').append('<button title="Find Next" class="buttons"  id="next"><span class="lui-icon lui-icon--arrow-down" aria-hidden="true"></button>');
$('.qui-editbarflat.qw-center').append('<button title="Find Previous" class="buttons" id="prev"><span class="lui-icon lui-icon--arrow-up" aria-hidden="true"></button>');
$('.qui-editbarflat.qw-center').append('<button title="Replace With" class="" id="showsearch"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 0 24 24" width="24px" fill="#ffffff"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M11 6c1.38 0 2.63.56 3.54 1.46L12 10h6V4l-2.05 2.05C14.68 4.78 12.93 4 11 4c-3.53 0-6.43 2.61-6.92 6H6.1c.46-2.28 2.48-4 4.9-4zm5.64 9.14c.66-.9 1.12-1.97 1.28-3.14H15.9c-.46 2.28-2.48 4-4.9 4-1.38 0-2.63-.56-3.54-1.46L10 12H4v6l2.05-2.05C7.32 17.22 9.07 18 11 18c1.55 0 2.98-.51 4.14-1.36L20 21.49 21.49 20l-4.85-4.86z"/></svg></span></button>');
$('.qui-editbarflat.qw-center').append('<input title="Replace With" class="" type="text" id="replaceText" name="search" placeholder="Replace with"/>');

$('.qui-editbarflat.qw-center').append('<button title="Replace" class="buttons" id="replace"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 0 24 24" width="24px" fill="#ffffff"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M7 7h10v3l4-4-4-4v3H5v6h2V7zm10 10H7v-3l-4 4 4 4v-3h12v-6h-2v4zm-4-2V9h-1l-2 1v1h1.5v4H13z"/></svg></button>');

$('.qui-editbarflat.qw-center').append('<button title="Replace All" class="buttons" id="replaceAll"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 0 24 24" width="24px" fill="#ffffff"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M7 7h10v3l4-4-4-4v3H5v6h2V7zm10 10H7v-3l-4 4 4 4v-3h12v-6h-2v4z"/></svg></button>');

$('.qui-editbarflat.qw-center').append('<button title="Undo" class="buttons" title="Undo Replace All" id="undo"><span class="lui-icon  lui-icon--back" aria-hidden="true"></span></button>');
$('.qui-editbarflat.qw-center').append('<button title="Redo" class="buttons" id="redo"><span class="lui-icon  lui-icon--forward" aria-hidden="true"></span></button>');
$('.qui-editbarflat.qw-center').append('<button title="Word Wrap" class="buttons" id="wraptext"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 0 24 24" width="24px" fill="#FFFFFF"><path d="M0 0h24v24H0z" fill="none"/><path d="M4 19h6v-2H4v2zM20 5H4v2h16V5zm-3 6H4v2h13.25c1.1 0 2 .9 2 2s-.9 2-2 2H15v-2l-3 3 3 3v-2h2c2.21 0 4-1.79 4-4s-1.79-4-4-4z"/></svg></button>');
// $('.qui-editbarflat.qw-center').append('<button class="buttons" id="hist">22222</button>');

$('.tab-content-wrapper').append('<span id="goto" class="status"><span id="status">Ln , Col</span> <- Click here to go to specific line</span> ');
// $('.tab-content-wrapper').append('<span class="goto" id="goto">Ln , Col</button>');


let bookmarkHtml = `
<div class="title-context" id="bmSection">
    <div class="title" q-translation="Devhub.ObjectsTitle">Bookmarks
    <span class="lui-icon lui-icon--arrow-down bm-icon" style="float:right"></span>
    </div>
</div>

<div id="sectionContent" class="visible" style="display:block">
    <div class="search-box">
        <div placeholder="Search Bookmark" class="lui-search lui-search--inverse">
            <span class="lui-icon  lui-icon--search  lui-search__search-icon"></span>
            <input id="bmSearch" class="lui-search__input" maxlength="255" q-placeholder="Search Bookmark" autocomplete="" spellcheck="false" type="text" placeholder="Search">
            <button id="bmSearchClear" class="lui-search__clear-button" title="Clear">
                <span class="lui-icon  lui-icon--small  lui-icon--close">
                </span>
            </button>
        </div>
    </div>

    <button id="clearBM" title="Clear All Bookmarks" class="lui-button lui-button--toolbar-inverse lui-button lui-button--toolbar">
        <span class="lui-button__text item-title" qva-direction="" x-dir-text="Save" dir="ltr">
            Clear All
        </span>
    </button>
        
    <div class="qv-panel-left borderbox" style="
    overflow: scroll;
    height: calc(100% - 38px - 28px);
">
        <ul id="bmList" class="lui-list lui-list--inverse">
        </ul>
    </div>
    
</div>

`
$('.qv-panel-assets').append(bookmarkHtml);

var undohist = null;
var redohist = null;
var beforeHistory = null;

var isSearching = false;
var lastAction = null;
var currentCursorPos = null;

function enableUndoRedo() {
    if (cmEditor) {
        let count = cmEditor.historySize();
        if (count.undo > 0) {
            $('#undo').prop('disabled', false);
        } else {

            $('#undo').prop('disabled', true);
        }

        if (count.redo > 0 || (lastAction == 'undoAll' && redohist)) {
            $('#redo').prop('disabled', false);
        } else {
            $('#redo').prop('disabled', true);
        }
    }
}

document.getElementById('clearBM').addEventListener('click', function () {
    if (confirm('Do you want to clear all bookmarks?')) {

        let activeTab = localStorage.getItem(local_activeTab)
        let memoryBookMark = JSON.parse(localStorage.getItem(local_bookmark) || '{}');
        if (memoryBookMark[activeTab]) {
            memoryBookMark[activeTab] = [];
        }
        localStorage.setItem(local_bookmark, JSON.stringify(memoryBookMark));
        highlightLine();
    }
});

$(".bm-icon").removeClass('up');

document.getElementById('bmSection').addEventListener('click', function () {
    if ($("#sectionContent").hasClass('visible')) {

        $(".bm-icon").addClass('up');
        $("#sectionContent").slideUp("slow", function () {
            $("#sectionContent").removeClass('visible')
            // Animation complete.
        });
    } else {

        $("#sectionContent").addClass('visible');
        $(".bm-icon").removeClass('up');

        $("#sectionContent").slideDown("slow", function () {
            // Animation complete.
        });
    }
});


var lineWrapping = false;
$('#wraptext').addClass('disable');
document.getElementById('wraptext').addEventListener('click', function () {

    if (cmEditor) {
        lineWrapping = ~lineWrapping;
        if (lineWrapping) {
            $('#wraptext').removeClass('disable');
        } else {
            $('#wraptext').addClass('disable');
        }
        cmEditor.setOption("lineWrapping", lineWrapping);
    }
});

document.getElementById('goto').addEventListener('click', function () {
    let d = prompt("Enter Line number (Example(Line:Character) - 45:15)")
    d = d.split(":")
    let line = parseInt(d[0]) - 1;
    let chr = d.length > 1 ? parseInt(d[1]) - 1 : 0;
    cmEditor.setSelection({ line: line, ch: chr });
    cmEditor.scrollIntoView({ line: line, ch: chr }, 100);
    cmEditor.focus()
});
document.getElementById('showsearch').addEventListener('click', function () {
    $('#searchText').show();
});
// document.getElementById('hist').addEventListener('click', function () {
//     console.log('undo', cmEditor.historySize(), currentCursorPos);
//     // console.log(cmEditor.getValue());
//     // hist = cmEditor.getValue()//cmEditor.getHistory();
// });
document.getElementById('undo').addEventListener('click', function () {
    console.log('undo', cmEditor.historySize(), currentCursorPos);

    // cmEditor.setHistory(hist);
    if (lastAction == 'replaceAll') {
        if (cmEditor) {
            redohist = cmEditor.getValue();
        }
        if (cmEditor && undohist) {
            cmEditor.setValue(undohist);
            cmEditor.setCursor(currentCursorPos);
            cmEditor.scrollIntoView(currentCursorPos, 20);
            undohist = null;
            if (beforeHistory) {
                cmEditor.setHistory(beforeHistory);
            }
        }
        lastAction = 'undoAll';
    } else {
        if (cmEditor) {
            cmEditor.undo();
            lastAction = null;
        }
    }
    enableUndoRedo();
    // cmEditor.focus()
});

document.getElementById('redo').addEventListener('click', function () {
    console.log('redo', cmEditor.historySize(), currentCursorPos);
    // cmEditor.setHistory(hist);
    if (lastAction == 'undoAll') {
        if (cmEditor) {
            undohist = cmEditor.getValue();
        }
        if (cmEditor && redohist) {
            cmEditor.setValue(redohist);
            cmEditor.setCursor(currentCursorPos);
            cmEditor.scrollIntoView(currentCursorPos, 20);
            redohist = null;
        }
        lastAction = 'replaceAll';
    } else if (lastAction != 'replaceAll') {
        if (cmEditor) {
            cmEditor.redo();
        }
    }
    enableUndoRedo();
    // cmEditor.focus()

});
document.getElementById('replace').addEventListener('click', function () {
    // var activeTab = parseInt(localStorage.getItem(local_activeTabNumber) || '0') - 2;
    // cmEditor = $('.CodeMirror')[activeTab].CodeMirror;
    // cmEditor.setOption("extraKeys", { "Alt-F": "findPersistent" });
    if (cursor && $('#replaceText').val()) {
        cursor.replace($('#replaceText').val());
        findNext();
    }

})
document.getElementById('replaceAll').addEventListener('click', function () {

    // var activeTab = parseInt(localStorage.getItem(local_activeTabNumber) || '0') - 2;
    // cmEditor = $('.CodeMirror')[activeTab].CodeMirror;
    // cmEditor.setOption("extraKeys", { "Alt-F": "findPersistent" });

    startSearch(true);
    if (cmEditor && cursor) {
        beforeHistory = cmEditor.getHistory();
        undohist = cmEditor.getValue();
        currentCursorPos = cmEditor.getCursor();
    }
    if (cursor && $('#replaceText').val()) {

        cursor.replace($('#replaceText').val());
        while (cmEditor && cursor.findNext()) {
            cursor.replace($('#replaceText').val());
        }
        lastAction = 'replaceAll';
        currentCursorPos = cmEditor.getCursor();
    }

})

var typingWait = null;

document.getElementById('bmSearch').addEventListener("input", function (event) {
    // var activeTab = parseInt(localStorage.getItem(local_activeTabNumber) || '0') - 2;
    // cmEditor = $('.CodeMirror')[activeTab].CodeMirror;
    // cursor = cmEditor.getSearchCursor($('#searchText').val(),
    //     { line: parseInt(localStorage.getItem(local_currentLineNumber)), ch: 0 },
    //     { caseFold: true, multiline: true });
    // localStorage.getItem(local_currentLineNumber)
    if ($('#bmSearch').val()) {

        $('#bmSearchClear').addClass('visible');
    } else {
        $('#bmSearchClear').removeClass('visible');

    }
    if (typingWait) {
        clearTimeout(typingWait);
    }

    typingWait = setTimeout(function () {
        updateBookmarkList()
    }, 1000)

});
document.getElementById('bmSearchClear').addEventListener("click", function (event) {
    // var activeTab = parseInt(localStorage.getItem(local_activeTabNumber) || '0') - 2;
    // cmEditor = $('.CodeMirror')[activeTab].CodeMirror;
    // cursor = cmEditor.getSearchCursor($('#searchText').val(),
    //     { line: parseInt(localStorage.getItem(local_currentLineNumber)), ch: 0 },
    //     { caseFold: true, multiline: true });
    // localStorage.getItem(local_currentLineNumber)
    $('#bmSearch').val('');
    $('#bmSearchClear').removeClass('visible');
    updateBookmarkList()


});


document.getElementById('searchText').addEventListener("input", function (event) {
    // var activeTab = parseInt(localStorage.getItem(local_activeTabNumber) || '0') - 2;
    // cmEditor = $('.CodeMirror')[activeTab].CodeMirror;
    // cursor = cmEditor.getSearchCursor($('#searchText').val(),
    //     { line: parseInt(localStorage.getItem(local_currentLineNumber)), ch: 0 },
    //     { caseFold: true, multiline: true });
    // localStorage.getItem(local_currentLineNumber)
    if (typingWait) {
        clearTimeout(typingWait);
    }

    typingWait = setTimeout(function () {
        startSearch();
    }, 1000);

});
// Execute a function when the user releases a key on the keyboard
document.getElementById('searchText').addEventListener("keyup", function (event) {
    // Number 13 is the "Enter" key on the keyboard
    if (event.keyCode === 13) {
        // Cancel the default action, if needed
        event.preventDefault();
        if (!cursor) {
            startSearch();
        } else {
            findNext();
        }
        // Trigger the button element with a click
        // document.getElementById("myBtn").click();
    }
});

var keydown = null;
var stopPropagationFuncTemp = Event.prototype.stopPropagation;
Event.prototype.stopPropagation = function (event) {
    // alert('123') /
    console.log('probigation', event, arguments, this)
    //
    stopPropagationFuncTemp.apply(this, arguments);
    let e = this;
    if ((e.keyCode == 70 && (e.ctrlKey || e.metaKey)) ||
        (e.keyCode == 191)) {
        keydown = new Date().getTime();
        console.log('finding');
        document.getElementById("searchText").focus();
        document.getElementById("searchText").focus();
        // setTimeout(() => {
        //     document.getElementById("searchText").focus();
        //     setTimeout(() => {
        //         document.getElementById("searchText").focus();
        //     }, 100);
        // }, 100);

    }
    // return true;
}

// $(window).keydown(function (e) {
//     console.log("ass" + " " + e.keyCode + " " + e.ctrlKey)
//     if ((e.keyCode == 70 && (e.ctrlKey || e.metaKey)) ||
//         (e.keyCode == 191)) {
//         keydown = new Date().getTime();
//         console.log('finding');
//         document.getElementById("searchText").focus();
//         document.getElementById("searchText").focus();
//     }

//     return true;
// }).blur(function () {
//     if (keydown !== null) {
//         var delta = new Date().getTime() - keydown;
//         if (delta >= 0 && delta < 1000) {
//             console.log('finding');
//             document.getElementById("searchText").focus();
//             document.getElementById("searchText").focus();
//         }
//         keydown = null;
//     }
// });

document.getElementById('next').addEventListener('click', function () {
    console.log('search', cursor);
    //document.getElementById("searchText").focus();
    if (!cursor) {

        startSearch();
    } else {
        findNext();
    }
})
document.getElementById('prev').addEventListener('click', function () {
    findPrev();
})
var looped = 0;
var tempAnnotate = null;



function startSearch(fromStart = false, linenumber = 0) {
    // cmEditor = document.querySelector('.CodeMirror').CodeMirror;
    if (tempAnnotate) {
        try {

            tempAnnotate.clear();

        } catch (e) {

        }
    }
    // $('.CodeMirror-search-match').remove();
    var activeTab = parseInt(localStorage.getItem(local_activeTabNumber) || '0') - 2;
    cmEditor = $('.CodeMirror')[activeTab].CodeMirror;
    if (cmEditor) {

        cmEditor.doc.getAllMarks().forEach(marker => marker.clear());

        console.log('searching', $('#searchText').val())
        if ($('#searchText').val()) {
            tempAnnotate = cmEditor.showMatchesOnScrollbar($('#searchText').val());
            // if (tempAnnotate) {
            // tempAnnotate.update();
            // } else {
            cmEditor.annotateScrollbar({
                listenForChanges: false,
                className: "CodeMirror-search-match"
            })
            // }

            let TempCursor = cmEditor.getSearchCursor($('#searchText').val(),
                { line: 0, ch: 0 },
                { caseFold: true, multiline: true });

            if (TempCursor && TempCursor.find(false)) {
                while (TempCursor.findNext(true)) {
                    cmEditor.markText(TempCursor.from(), TempCursor.to(), { className: "cm-searching", shared: true });
                }
            }
            cursor = cmEditor.getSearchCursor($('#searchText').val(),
                fromStart ? { line: linenumber, ch: 0 } : { line: parseInt(localStorage.getItem(local_currentLineNumber)), ch: 0 },
                { caseFold: true, multiline: true });
        } else {
            cursor = null;
            // cmEditor.clearSelection();
            console.log(cmEditor.getCursor())
            cmEditor.setSelection(cmEditor.getCursor());
        }

        if (cursor && cursor.find(false)) {
            isSearching = true;
            //move to that position.        
            cmEditor.setSelection(cursor.from(), cursor.to());
            cmEditor.scrollIntoView({ from: cursor.from(), to: cursor.to() }, 20);
            looped = 0;
        } else {
            cursor = null;
            isSearching = false;
            // startSearch(true)
            looped++;
            if (looped == 1) {
                startSearch(true);
            }
        }
    }
}

function findNext() {
    if (cmEditor && cursor.findNext()) {
        // editor.markText(
        //     cursor.from(),
        //     cursor.to(),
        //     { className: 'highlight' }
        // );
        isSearching = true;
        cmEditor.setSelection(cursor.from(), cursor.to());
        cmEditor.scrollIntoView({ from: cursor.from(), to: cursor.to() }, 20);
    } else {
        isSearching = false;
        startSearch(true)
    }
}
function findPrev() {
    if (cmEditor && cursor.findPrevious()) {
        // editor.markText(
        //     cursor.from(),
        //     cursor.to(),
        //     { className: 'highlight' }
        // );
        isSearching = true;
        cmEditor.setSelection(cursor.from(), cursor.to());
        cmEditor.scrollIntoView({ from: cursor.from(), to: cursor.to() }, 20);
    } else {
        isSearching = false;
        if (cmEditor) {
            startSearch(true, cmEditor.lastLine())
        }
    }
}

var lineCount = 0;

function initEditor() {

    // DONE: Fix Initial Tab and Tab Switch
    var activeTab = parseInt(localStorage.getItem(local_activeTabNumber) || '0') - 2;
    cmEditor = $('.CodeMirror')[activeTab].CodeMirror;
    lineCount = cmEditor.lineCount();
    enableUndoRedo();
    console.log("active cursor", cmEditor.getCursor())


    cmEditor.on('changes', function (c, changesObj) {
        let previousLine = lineCount;
        lineCount = cmEditor.lineCount();
        let increasedOrDecreased = Math.abs(previousLine - lineCount);
        let direction = lineCount > previousLine ? 'added' : (lineCount < previousLine ? 'deleted' : 'No Change');
        let lastChange = changesObj[0];

        console.log('changes', changesObj, increasedOrDecreased, ' lines ', direction)
        console.log('changes', 'last change is on ', lastChange.from.line + 1, ' to ', lastChange.to.line + 1)

        if (direction === 'added') {

            let activeTab = localStorage.getItem(local_activeTab)
            let memoryBookMark = JSON.parse(localStorage.getItem(local_bookmark) || '{}');
            memoryBookMark[activeTab].filter(function (x) {
                return parseInt(x.lineNumber) >= lastChange.to.line + 1;
            }).forEach(function (x) {
                x.lineNumber = parseInt(x.lineNumber) + increasedOrDecreased
            })
            localStorage.setItem(local_bookmark, JSON.stringify(memoryBookMark));

            highlightLine();

        } else if (direction === 'deleted') {
            let activeTab = localStorage.getItem(local_activeTab)
            let memoryBookMark = JSON.parse(localStorage.getItem(local_bookmark) || '{}');
            memoryBookMark[activeTab].filter(function (x) {
                return parseInt(x.lineNumber) >= lastChange.to.line + 1;
            }).forEach(function (x) {
                x.lineNumber = parseInt(x.lineNumber) - increasedOrDecreased
            })
            localStorage.setItem(local_bookmark, JSON.stringify(memoryBookMark));

            highlightLine();
        }

        // cc.forEach(function (changeObj) {

        //     console.log('content changes', changeObj, changeObj.text.map((str) => str));
        //     console.log('content changes', changeObj.origin, changeObj.from.line + 1, changeObj.from.ch + 1, changeObj.to.line + 1, changeObj.to.ch + 1);
        // })

        enableUndoRedo();

    })

    $('.CodeMirror-line').unbind('click', clicked);
    $('.CodeMirror-line').on('click', clicked);

    $('.CodeMirror-linenumber').unbind('click', bookmark);
    $('.CodeMirror-linenumber').on('click', bookmark)
    highlightLine();
    cmEditor.on('cursorActivity', function () {
        console.log("active cursor", cmEditor.getCursor())
        let cur = cmEditor.getCursor();
        $('#status').html(`Ln ${cur.line + 1}, Col ${cur.ch + 1}`);
        // if (!isSearching) {
        //     cursor = null;
        //     let New_cursor = cmEditor.getCursor();
        //     console.log('line changes', New_cursor.line + 1);
        //     localStorage.setItem(local_currentLineNumber, New_cursor.line + 1);
        // }

        $('.CodeMirror-line').unbind('click', clicked);
        $('.CodeMirror-line').on('click', clicked);

        $('.CodeMirror-linenumber').unbind('click', bookmark);
        $('.CodeMirror-linenumber').on('click', bookmark)


    })



}

//setTimeout(initEditor, 3000)

function clicked() {

    // var _this = this;
    // var linenumber = $(_this).parent().find('.CodeMirror-linenumber').text()
    // // console.log('linenumber', linenumber);
    if (cmEditor) {
        let New_cursor = cmEditor.getCursor();
        // console.log('line changes', New_cursor.line + 1);
        localStorage.setItem(local_currentLineNumber, New_cursor.line + 1);
        // localStorage.setItem(local_currentLineNumber, linenumber);
        cursor = null;
        // cmEditor.clearSelection();
    }
}


function bookmark() {


    console.log("asas");
    var _this = this;
    var linenumber = $(_this).text();

    var lineContent = $(_this).parent().parent().find('.CodeMirror-line').text()

    let activeTab = localStorage.getItem(local_activeTab)
    let memoryBookMark = JSON.parse(localStorage.getItem(local_bookmark) || '{}');

    if ($(this).hasClass('active')) {
        if (memoryBookMark[activeTab] && memoryBookMark[activeTab].length > 0) {
            memoryBookMark[activeTab] = memoryBookMark[activeTab].filter(function (x) {
                return x.lineNumber != linenumber;
            })
        } else {

        }
        $(this).removeClass('active');
    } else {
        if (memoryBookMark[activeTab] && memoryBookMark[activeTab].length > 0) {
            memoryBookMark[activeTab].push({
                lineNumber: linenumber,
                line: lineContent
            })
        } else {
            memoryBookMark[activeTab] = [{
                lineNumber: linenumber,
                line: lineContent
            }];

        }
        $(this).addClass('active');
    }
    localStorage.setItem(local_bookmark, JSON.stringify(memoryBookMark));

    updateBookmarkList();

}

var escape = document.createElement('textarea');
function escapeHTML(html) {
    escape.textContent = html;
    return escape.innerHTML;
}

function unescapeHTML(html) {
    escape.innerHTML = html;
    return escape.textContent;
}

function updateBookmarkList(filter = $('#bmSearch').val()) {
    $('#bmList').empty();
    let activeTab = localStorage.getItem(local_activeTab)
    let memoryBookMark = JSON.parse(localStorage.getItem(local_bookmark) || '{}');
    if (memoryBookMark[activeTab] && memoryBookMark[activeTab].length > 0) {
        memoryBookMark[activeTab]
            .filter(function (x) {
                if (!filter) {
                    return true;
                }

                //return the items without filter when searchterm is empty
                let regEx = new RegExp(filter, 'gi') //create regex based on search term to filter the items 
                return regEx.test(x.line) || regEx.test(x.lineNumber); //if the item passes the regex text, return that item

            })
            .forEach(function (x) {
                $('#bmList').append(`<li style="cursor:pointer" data-line="${x.lineNumber}" class="lui-list__item lui-list__action library-item header header-mashup bmList-item">
                <div class="lui-list__text lui-list__text--ellipsis" text="${x.lineNumber}">
                ${x.lineNumber} : ${escapeHTML(x.line.trim())}
                </div>
            </li>`)
            })

        $('.bmList-item').on('click', function () {
            let line = parseInt($(this).attr('data-line')) - 1;
            cmEditor.setSelection({ line: line, ch: 0 });
            cmEditor.scrollIntoView({ line: line, ch: 0 }, 100);
            cmEditor.focus()
        })
    }
}

function highlightLine() {
    let activeTab = localStorage.getItem(local_activeTab)
    let memoryBookMark = JSON.parse(localStorage.getItem(local_bookmark) || '{}');
    updateBookmarkList();
    $('.CodeMirror-linenumber').removeClass('active');


    $('.CodeMirror-linenumber').each(function () {
        var _this = this;
        var linenumber = $(_this).text();


        if (memoryBookMark[activeTab] && memoryBookMark[activeTab].length > 0) {
            memoryBookMark[activeTab].forEach(function (x) {
                if (x.lineNumber == linenumber) {
                    $(_this).addClass('active');
                }
            })
        }
    })
}

// while (cursor.findNext()) {
//     editor.markText(
//         cursor.from(),
//         cursor.to(),
//         { className: 'highlight' }
//     );
// }

// //Injected.js
// window.addEventListener("message", function(request) { 
//     alert("Asas");
//     if (request.data == "YourName_expectedMessage") //note that there are likely many script on the page or it's child frames that also send messages to this page, so you better name your message so that is unique in the entire world.
//     { 
//         alert("Asas");
//     } 

// }, true);

$('<div id="tabNav"></div>').insertAfter(".work-area-mashup-editor");

var tabs = []
var scrollMemory = JSON.parse(localStorage.getItem(local_scrollMemory) || "{}");
setTimeout(function () {

    $("#mashup-editor-stage .lui-tab").each((iter, element) => {
        var defaultTab = localStorage.getItem(local_activeTab);

        var tab = $(element).find(".lui-tab__text").text().replace("*", "")
        if (defaultTab && defaultTab === tab) {
            $(element).click();

            setTimeout(function () {

                var scrollMemory = JSON.parse(localStorage.getItem(local_scrollMemory) || "{}");
                document.querySelector("#mashup-editor-stage > div.qv-panel-content.flex-row > div.work-area-mashup-editor.work-area.ng-scope > div > div.tab-content-wrapper.ng-scope > div:nth-child(" + (iter + 1) + ") > div > div > div > div.CodeMirror-scroll").scrollTop = scrollMemory[defaultTab];
                initEditor();
            }, 300)
        }
        console.log($(element).hasClass("lui-active"), $(element).find(".lui-tab__text").text(), iter);

        $(element).find(".lui-tab__text").attr("tabIndex", iter + 1);

        tabs.push($(element).find(".lui-tab__text"));
        $('#tabNav').append('<div title="' + ($(element).find(".lui-tab__text").text()) + '" tab-name="' + tab + '" tab-index="' + iter + '" class="tabElem ' + (defaultTab == tab ? 'active' : '') + '">' + ($(element).find(".lui-tab__text").text().replace("*", "")) + '</div>')

        $(element).find(".lui-tab__text").click(function () {
            console.log($(this).text())
            var tabName = $(this).text().replace("*", "")
            var tabIndex = $(this).attr("tabIndex");
            localStorage.setItem(local_previousTab, localStorage.getItem(local_activeTab));
            localStorage.setItem(local_activeTab, tabName);
            localStorage.setItem(local_activeTabNumber, tabIndex);
            localStorage.setItem(local_disableScroll, 1);


            $('.tabElem').removeClass('active');


            setTimeout(function () {

                var scrollMemory = JSON.parse(localStorage.getItem(local_scrollMemory) || "{}");
                document.querySelector("#mashup-editor-stage > div.qv-panel-content.flex-row > div.work-area-mashup-editor.work-area.ng-scope > div > div.tab-content-wrapper.ng-scope > div:nth-child(" + (tabIndex) + ") > div > div > div > div.CodeMirror-scroll").scrollTop = scrollMemory[tabName];
                initEditor();
            }, 1000)
            $($('.tabElem')[tabIndex - 1]).addClass('active');


        })

        $("#mashup-editor-stage > div.qv-panel-content.flex-row > div.work-area-mashup-editor.work-area.ng-scope > div > div.tab-content-wrapper.ng-scope > div:nth-child(" + (iter + 1) + ") > div > div > div > div.CodeMirror-scroll").scroll(function () {


            $('.CodeMirror-line').unbind('click', clicked);
            $('.CodeMirror-line').on('click', clicked);

            $('.CodeMirror-linenumber').unbind('click', bookmark);
            $('.CodeMirror-linenumber').on('click', bookmark);

            highlightLine();

            var currentTab = localStorage.getItem(local_activeTab);
            var scrollMemory = JSON.parse(localStorage.getItem(local_scrollMemory) || "{}");
            var tab = $(element).find(".lui-tab__text").text().replace("*", "")
            if ($(this).scrollTop() != 0 && localStorage.getItem(local_disableScroll) == '0') {

                scrollMemory[tab] = $(this).scrollTop();
                if ($(this).scrollTop() == 673) {
                    debugger;
                }
                console.log(scrollMemory)
                localStorage.setItem(local_scrollMemory, JSON.stringify(scrollMemory));
            } else {
                localStorage.setItem(local_disableScroll, 0);
            }

            // $('.CodeMirror-line').click(function () {

            // 	var _this = this;
            // 	var linenumber = $(_this).parent().find('.CodeMirror-linenumber').text()
            // 	// console.log('linenumber', linenumber);
            // 	localStorage.setItem(local_currentLineNumber, linenumber);
            // })
        })
    })

    $('.tabElem').click(function () {
        $('.tabElem').removeClass('active');
        $(this).addClass('active');
        var index = $(this).attr('tab-index');
        tabs[index].click();

        initEditor();
        // window.postMessage("YourName_expectedMessage", "*")
    })

}, 1000)


